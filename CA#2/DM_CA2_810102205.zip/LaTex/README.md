# Seminar Template

A LaTeX template for Homeworks and assignments in Persian for university of Tehran.

by: Amin Khorasani